<?php

namespace App\Models\SettingDoc;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class DocDpart extends Model
{
    use HasFactory;

    protected $table = "dpart_it";
}
