<?php

namespace App\Models\SettingDoc;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class DocSheft extends Model
{
    use HasFactory;

    protected $table = "tbl_docshelfit";
}
