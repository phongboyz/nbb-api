<?php

namespace App\Models\Doc;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class LogDocument extends Model
{
    use HasFactory;

    protected $table = 'log_docs';
}
