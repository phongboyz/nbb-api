<?php

namespace App\Models\Doc;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class DocumentIt extends Model
{
    use HasFactory;

    protected $table = 'tbl_doc_it';
}
